input = input("prompt for input")
x, y, z = input.split(" ")
if y == "+":
    print(float(x) + float(z))
if y == "-":
    print(float(x) - float(z))
if y == "*":
    print(float(x) * float(z))
if y == "/":
    print(float(x) / float(z))