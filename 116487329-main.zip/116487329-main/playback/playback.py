input = input()
print(input.replace(" ", "..."))