input = input()
print(input.lower())