input = input()
input2 = input.replace(":(", "🙁")
print(input2.replace(":)", "🙂"))