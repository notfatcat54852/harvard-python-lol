input = input("hello")
if input == "Hello" or input == " Hello ":
    print("$0")
elif input == "Hello, Newman":
    print("$0")
elif input == "How you doing?":
    print("$20")
else:
    print("$100")