input = input()
input = int(input) * pow(300000000, 2)
print(input)